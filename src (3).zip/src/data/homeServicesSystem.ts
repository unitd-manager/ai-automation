// Content for the two redesigned Home Services sections. Everything here follows the
// same flow as the hero workflow:
// Customer call → AI voice agent → Qualification → Service type & location → CRM →
// Appointment → Technician dispatched → Follow-up

/* ---------- "One call, two outcomes" timeline ---------- */

export interface FrontDeskRow {
  /** Scenario clock time (illustrative). */
  time: string;
  /** Must match a string in the home-services `workflow` array. */
  stage: string;
  without: string;
  withUs: string;
}

export const frontDeskScenario = {
  label: "Illustrative scenario",
  headline: "Tuesday, 6:47 PM. A pipe bursts, and you're on another job.",
};

export const frontDeskRows: FrontDeskRow[] = [
  {
    time: "6:47 PM",
    stage: "Customer call",
    without: "Your phone rings while you're under a sink. It goes to voicemail.",
    withUs: "The call is picked up and answered professionally, even mid-job.",
  },
  {
    time: "6:48 PM",
    stage: "Qualification",
    without: "Nobody can tell an emergency from a quote request until someone calls back.",
    withUs: "The AI asks about the leak, the scope and the timeline, and flags it as an emergency.",
  },
  {
    time: "6:49 PM",
    stage: "CRM",
    without: "The details live in a voicemail you'll replay later, if you remember.",
    withUs: "Service type, address and photos land in your CRM, ready for the crew.",
  },
  {
    time: "6:52 PM",
    stage: "Technician dispatched",
    without: "By the time you call back, the customer has already booked a competitor.",
    withUs: "The job is routed to the on-call technician and the customer gets a confirmation.",
  },
  {
    time: "Next day",
    stage: "Follow-up",
    without: "The estimate goes out and nobody follows up. Your evening goes to returning calls.",
    withUs: "Follow-ups run on open estimates until the customer replies. Your evening stays yours.",
  },
];

/* ---------- "Inside the system" explorer ---------- */

export type Channel = "voice" | "sms" | "email";

export interface ThreadLine {
  from: "customer" | "ai" | "system";
  text: string;
}

export interface SystemFeatureMeta {
  /** Must match a title in `industries[home-services].features`, which supplies the description. */
  title: string;
  agent: string;
  /** Workflow stages this feature runs on (must match the home-services `workflow` strings). */
  stages: string[];
  channels: Channel[];
  thread: ThreadLine[];
}

export const AGENT_RESPONSE = "AI Response & Booking Agent";
export const AGENT_RETENTION = "AI Follow-Up & Retention Agent";

export const systemFeatures: SystemFeatureMeta[] = [
  {
    title: "Lead Qualification",
    agent: AGENT_RESPONSE,
    stages: ["AI voice agent", "Qualification"],
    channels: ["voice", "sms"],
    thread: [
      { from: "customer", text: "My AC just stopped and the house is already hot." },
      { from: "ai", text: "I'm sorry about that. I can get a technician out. What's the address, and when did it stop?" },
      { from: "system", text: "Scope captured · Timeline: today · Flagged as urgent" },
    ],
  },
  {
    title: "Service Area & Scheduling",
    agent: AGENT_RESPONSE,
    stages: ["Service type & location", "CRM"],
    channels: ["voice", "sms"],
    thread: [
      { from: "customer", text: "Do you work in my area, and do you handle water heaters?" },
      { from: "ai", text: "Let me check your address against our service area and trades." },
      { from: "system", text: "In area · Trade matched · Saved to CRM" },
    ],
  },
  {
    title: "Estimate Booking",
    agent: AGENT_RESPONSE,
    stages: ["Appointment"],
    channels: ["voice", "sms"],
    thread: [
      { from: "customer", text: "I need a roof estimate after the storm. Here are some photos." },
      { from: "ai", text: "Thanks, I have the photos. I have Thursday at 10 AM or Friday at 2 PM. Which works?" },
      { from: "system", text: "Booked against live availability · Confirmation sent" },
    ],
  },
  {
    title: "Job Dispatching",
    agent: AGENT_RESPONSE,
    stages: ["Technician dispatched"],
    channels: ["voice", "sms"],
    thread: [
      { from: "customer", text: "A pipe burst and water is coming through the ceiling." },
      { from: "system", text: "Priority: Emergency · Specialty: Plumbing" },
      { from: "system", text: "Routed to the on-call technician by availability and location" },
      { from: "ai", text: "A technician has been dispatched. You'll get a confirmation by text." },
    ],
  },
  {
    title: "Quote Follow-Ups",
    agent: AGENT_RETENTION,
    stages: ["Follow-up"],
    channels: ["sms", "email"],
    thread: [
      { from: "system", text: "Estimate sent · No reply yet" },
      { from: "ai", text: "Hi, just checking in on the estimate we sent. Happy to answer questions or lock in a time." },
      { from: "customer", text: "Yes, let's get it booked for next week." },
    ],
  },
  {
    title: "Review & Reactivation",
    agent: AGENT_RETENTION,
    stages: ["Follow-up"],
    channels: ["sms", "email"],
    thread: [
      { from: "system", text: "Job completed" },
      { from: "ai", text: "Thanks for choosing us. Would you take a minute to leave a review?" },
      { from: "system", text: "Six months later · Customer hasn't booked since" },
      { from: "ai", text: "It's been a while since your last visit. Want to book a seasonal check-up?" },
    ],
  },
];
